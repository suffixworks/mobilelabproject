<?php
/**
 * Front page = News feed (built-in Posts) + browse-by-year filter.
 * The year filter and scroll fade-in are handled by app.js.
 *
 * @package mobile-lab
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<div class="page">
	<div class="feed">
		<?php
		$news = new WP_Query( array(
			'post_type'      => 'post',
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );
		if ( $news->have_posts() ) :
			$first = true;
			while ( $news->have_posts() ) : $news->the_post();
				?>
				<article class="entry<?php echo $first ? ' first' : ''; ?>" data-year="<?php echo esc_attr( get_the_date( 'Y' ) ); ?>">
					<p class="date"><?php echo esc_html( get_the_date( 'F Y' ) ); ?></p>
					<?php if ( has_post_thumbnail() ) : ?>
						<div class="ml-img"><?php the_post_thumbnail( 'large' ); ?></div>
					<?php endif; ?>
					<h2 class="title"><?php the_title(); ?></h2>
					<?php // Always show the full post here — News is read in the feed, not on a detail page.
					$GLOBALS['more'] = 1; ?>
					<div class="entry-content"><?php the_content( '' ); ?></div>
				</article>
				<?php
				$first = false;
			endwhile;
			wp_reset_postdata();
		endif;
		?>
		<nav class="pager">
			<?php for ( $y = (int) date( 'Y' ); $y >= 2010; $y-- ) : ?>
				<button class="yr" data-year="<?php echo esc_attr( $y ); ?>"><?php echo esc_html( $y ); ?></button>
			<?php endfor; ?>
		</nav>
	</div>
</div>
<?php get_footer(); ?>
